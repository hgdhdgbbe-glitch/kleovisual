package com.darkclient;

public final class Config {
    private Config() {}

    public static boolean hudEnabled = true;
    public static boolean showWeather = true;
    public static boolean showArmor = true;
    public static boolean fpsBoost = false;

    // 0 yashil, 1 binafsha, 2 ko'k, 3 qizil, 4 sariq, 5 pushti
    public static int accent = 0;
    public static final int[] ACCENTS = {
        0xFF4ADE80, 0xFFA78BFA, 0xFF60A5FA, 0xFFF87171, 0xFFFBBF24, 0xFFF472B6
    };
    public static final String[] ACCENT_NAMES = {
        "Yashil", "Binafsha", "Ko'k", "Qizil", "Sariq", "Pushti"
    };

    // 0 o'chiq, 1 yulduz, 2 yurak, 3 olov, 4 ruh olovi
    public static int aura = 0;
    public static final String[] AURA_NAMES = {
        "O'chiq", "Yulduz", "Yurak", "Olov", "Ruh olovi"
    };

    public static String emoteText = "";
    public static long emoteUntil = 0;

    public static int accentColor() {
        return ACCENTS[accent];
    }
}
