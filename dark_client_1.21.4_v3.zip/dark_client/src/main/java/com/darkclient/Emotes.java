package com.darkclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.Hand;

public final class Emotes {
    public static final String[] NAMES = {"Yurak", "Musiqa", "Xursand", "Jahl", "Qo'l silkitish"};

    private Emotes() {}

    public static void play(MinecraftClient mc, int id) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;
        Config.emoteText = NAMES[id];
        Config.emoteUntil = System.currentTimeMillis() + 2500;
        switch (id) {
            case 0 -> burst(mc, ParticleTypes.HEART, 10);
            case 1 -> burst(mc, ParticleTypes.NOTE, 8);
            case 2 -> burst(mc, ParticleTypes.HAPPY_VILLAGER, 10);
            case 3 -> burst(mc, ParticleTypes.ANGRY_VILLAGER, 6);
            case 4 -> p.swingHand(Hand.MAIN_HAND);
            default -> { }
        }
    }

    private static void burst(MinecraftClient mc, ParticleEffect type, int count) {
        ClientPlayerEntity p = mc.player;
        for (int i = 0; i < count; i++) {
            double ox = (mc.world.random.nextDouble() - 0.5) * 0.8;
            double oz = (mc.world.random.nextDouble() - 0.5) * 0.8;
            double oy = 1.9 + mc.world.random.nextDouble() * 0.4;
            mc.world.addParticle(type, p.getX() + ox, p.getY() + oy, p.getZ() + oz, 0, 0.05, 0);
        }
    }
}
