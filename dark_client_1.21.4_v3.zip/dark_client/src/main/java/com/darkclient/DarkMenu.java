package com.darkclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class DarkMenu extends Screen {
    public DarkMenu() {
        super(Text.literal("dark_client"));
    }

    private static String onOff(boolean v) {
        return v ? "YOQILGAN" : "O'CHIRILGAN";
    }

    @Override
    protected void init() {
        int bw = 140, bh = 20, gap = 4, colGap = 6;
        int leftX = this.width / 2 - bw - colGap / 2;
        int rightX = this.width / 2 + colGap / 2;
        int top = Math.max(30, this.height / 2 - 75);

        // Chap ustun: emotsiyalar
        for (int i = 0; i < Emotes.NAMES.length; i++) {
            final int id = i;
            addDrawableChild(ButtonWidget.builder(Text.literal("Emotsiya: " + Emotes.NAMES[i]),
                b -> Emotes.play(MinecraftClient.getInstance(), id))
                .dimensions(leftX, top + i * (bh + gap), bw, bh).build());
        }

        // O'ng ustun: kosmetika va sozlamalar
        int y = top;
        addDrawableChild(ButtonWidget.builder(Text.literal("Aura: " + Config.AURA_NAMES[Config.aura]), b -> {
            Config.aura = (Config.aura + 1) % Config.AURA_NAMES.length;
            b.setMessage(Text.literal("Aura: " + Config.AURA_NAMES[Config.aura]));
        }).dimensions(rightX, y, bw, bh).build());

        y += bh + gap;
        addDrawableChild(ButtonWidget.builder(Text.literal("Rang: " + Config.ACCENT_NAMES[Config.accent]), b -> {
            Config.accent = (Config.accent + 1) % Config.ACCENTS.length;
            b.setMessage(Text.literal("Rang: " + Config.ACCENT_NAMES[Config.accent]));
        }).dimensions(rightX, y, bw, bh).build());

        y += bh + gap;
        addDrawableChild(ButtonWidget.builder(Text.literal("FPS Boost: " + onOff(Config.fpsBoost)), b -> {
            Config.fpsBoost = !Config.fpsBoost;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (Config.fpsBoost) FpsBoost.apply(mc); else FpsBoost.revert(mc);
            b.setMessage(Text.literal("FPS Boost: " + onOff(Config.fpsBoost)));
        }).dimensions(rightX, y, bw, bh).build());

        y += bh + gap;
        addDrawableChild(ButtonWidget.builder(Text.literal("Ob-havo: " + onOff(Config.showWeather)), b -> {
            Config.showWeather = !Config.showWeather;
            b.setMessage(Text.literal("Ob-havo: " + onOff(Config.showWeather)));
        }).dimensions(rightX, y, bw, bh).build());

        y += bh + gap;
        addDrawableChild(ButtonWidget.builder(Text.literal("Zirh paneli: " + onOff(Config.showArmor)), b -> {
            Config.showArmor = !Config.showArmor;
            b.setMessage(Text.literal("Zirh paneli: " + onOff(Config.showArmor)));
        }).dimensions(rightX, y, bw, bh).build());

        // Pastda: yopish
        int closeY = top + 5 * (bh + gap) + 6;
        addDrawableChild(ButtonWidget.builder(Text.literal("Yopish"), b -> close())
            .dimensions(this.width / 2 - 70, closeY, 140, bh).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("dark_client"),
            this.width / 2, 12, Config.accentColor());
    }
}
