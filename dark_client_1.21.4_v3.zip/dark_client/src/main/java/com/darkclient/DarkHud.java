package com.darkclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public final class DarkHud {
    private static final int BG = 0xE61A1F1E;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFF9CA3AF;
    private static final int SLOT = 0x40FFFFFF;
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");
    private static final EquipmentSlot[] ARMOR = {
        EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private DarkHud() {}

    public static void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.hudEnabled || mc.player == null || mc.world == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();

        topBar(ctx, tr, mc, sw);
        infoRow(ctx, tr, mc, sw);
        if (Config.showWeather) weather(ctx, tr, mc);
        effects(ctx, tr, mc);
        coords(ctx, tr, mc, sh);
        health(ctx, tr, mc, sh);
        if (Config.showArmor) armor(ctx, tr, mc, sw, sh);
        emoteBubble(ctx, tr, sw, sh);
        hotbar(ctx, tr, mc, sw, sh);

        String hint = "/dark  |  Right Shift";
        ctx.drawText(tr, hint, sw - tr.getWidth(hint) - 6, 4, GRAY, false);
    }

    private static void topBar(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int sw) {
        String time = LocalTime.now().format(TIME);
        String name = "dark_client";
        String fps = mc.getCurrentFps() + " fps";
        int gap = 10;
        int w = tr.getWidth(time) + tr.getWidth(name) + tr.getWidth(fps) + gap * 4;
        int x = (sw - w) / 2;
        int y = 6;
        roundRect(ctx, x, y, w, 20, 10, BG);
        int cx = x + gap;
        ctx.drawText(tr, time, cx, y + 6, WHITE, false);
        cx += tr.getWidth(time) + gap;
        ctx.drawText(tr, name, cx, y + 6, Config.accentColor(), false);
        cx += tr.getWidth(name) + gap;
        ctx.drawText(tr, fps, cx, y + 6, GRAY, false);
    }

    private static void infoRow(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int sw) {
        int ping = 0;
        if (mc.getNetworkHandler() != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (e != null) ping = e.getLatency();
        }
        String pingText = ping + " ms";
        String server = mc.isInSingleplayer() ? "Yakka o'yin"
                : (mc.getCurrentServerEntry() != null ? mc.getCurrentServerEntry().address : "Server");
        int gap = 10;
        int w = tr.getWidth(pingText) + tr.getWidth(server) + gap * 3;
        int x = (sw - w) / 2;
        int y = 30;
        roundRect(ctx, x, y, w, 20, 10, BG);
        ctx.drawText(tr, pingText, x + gap, y + 6, WHITE, false);
        ctx.drawText(tr, server, x + gap * 2 + tr.getWidth(pingText), y + 6, Config.accentColor(), false);
    }

    private static final int WEATHER_H = 64;
    private static final String[] MOON = {
        "To'lin oy", "Kamayayotgan oy", "Oxirgi chorak", "Kamayayotgan hilol",
        "Yangi oy", "O'sayotgan hilol", "Birinchi chorak", "O'sayotgan oy"
    };

    private static void weather(DrawContext ctx, TextRenderer tr, MinecraftClient mc) {
        var biomeEntry = mc.world.getBiome(mc.player.getBlockPos());
        String path = biomeEntry.getKey().map(k -> k.getValue().getPath()).orElse("");
        float temp = biomeEntry.value().getTemperature();
        boolean sky = mc.world.getDimension().hasSkyLight();

        String state;
        if (!sky) {
            state = "Ob-havo yo'q";
        } else if (mc.world.isThundering()) {
            state = "Momaqaldiroq";
        } else if (mc.world.isRaining()) {
            int pct = Math.round(mc.world.getRainGradient(1.0f) * 100);
            state = (temp < 0.15f ? "Qor" : "Yomg'ir") + " " + pct + "%";
        } else {
            state = "Ochiq osmon";
        }

        long t = mc.world.getTimeOfDay() % 24000L;
        String head = "Ob-havo · " + (t < 13000L || t >= 23000L ? "Kunduz" : "Tun");
        String line3 = biomeName(path) + " · ~" + Math.round(temp * 25f) + "°C";
        String line4 = "Oy: " + MOON[mc.world.getMoonPhase() & 7];
        String line5 = "";
        if (sky) {
            long left;
            String label;
            if (t < 13000L) { left = 13000L - t; label = "Tungacha: "; }
            else if (t < 23000L) { left = 23000L - t; label = "Tongacha: "; }
            else { left = 24000L - t + 13000L; label = "Tungacha: "; }
            long sec = left / 20L;
            line5 = label + (sec / 60) + ":" + String.format("%02d", sec % 60);
        }

        int w = 0;
        for (String l : new String[]{head, state, line3, line4, line5}) w = Math.max(w, tr.getWidth(l));
        w += 16;
        int x = 6, y = 6;
        roundRect(ctx, x, y, w, WEATHER_H, 8, BG);
        ctx.drawText(tr, head, x + 8, y + 6, GRAY, false);
        ctx.drawText(tr, state, x + 8, y + 17, Config.accentColor(), false);
        ctx.drawText(tr, line3, x + 8, y + 28, WHITE, false);
        ctx.drawText(tr, line4, x + 8, y + 39, WHITE, false);
        ctx.drawText(tr, line5, x + 8, y + 50, GRAY, false);
    }

    private static String biomeName(String path) {
        return switch (path) {
            case "plains" -> "Tekislik";
            case "forest" -> "O'rmon";
            case "birch_forest" -> "Qayin o'rmoni";
            case "dark_forest" -> "Qorong'i o'rmon";
            case "desert" -> "Cho'l";
            case "savanna" -> "Savanna";
            case "jungle" -> "Jungli";
            case "taiga" -> "Tayga";
            case "snowy_plains" -> "Qorli tekislik";
            case "snowy_taiga" -> "Qorli tayga";
            case "swamp" -> "Botqoq";
            case "ocean", "deep_ocean" -> "Okean";
            case "river" -> "Daryo";
            case "beach" -> "Plyaj";
            case "mountains", "windswept_hills" -> "Tog'lar";
            case "badlands" -> "Badlends";
            case "cherry_grove" -> "Gilos bog'i";
            case "meadow" -> "O'tloq";
            case "nether_wastes" -> "Nether cho'li";
            case "the_end" -> "End";
            case "" -> "Noma'lum";
            default -> {
                String n = path.replace('_', ' ');
                yield Character.toUpperCase(n.charAt(0)) + n.substring(1);
            }
        };
    }

    private static void effects(DrawContext ctx, TextRenderer tr, MinecraftClient mc) {
        int n = mc.player.getStatusEffects().size();
        String text = "Effektlar: " + n;
        int w = tr.getWidth(text) + 16;
        int x = 6, y = Config.showWeather ? 6 + WEATHER_H + 6 : 6;
        roundRect(ctx, x, y, w, 18, 8, BG);
        ctx.drawText(tr, text, x + 8, y + 5, WHITE, false);
    }

    private static void coords(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int sh) {
        String text = mc.player.getBlockX() + "x " + mc.player.getBlockY() + "y " + mc.player.getBlockZ() + "z";
        int w = tr.getWidth(text) + 16;
        int x = 6, y = sh - 24;
        roundRect(ctx, x, y, w, 18, 9, BG);
        ctx.drawText(tr, text, x + 8, y + 5, WHITE, false);
    }

    private static void health(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int sh) {
        String name = mc.player.getName().getString();
        int hp = (int) Math.ceil(mc.player.getHealth());
        float ratio = Math.max(0f, Math.min(1f, mc.player.getHealth() / mc.player.getMaxHealth()));
        int w = 110, h = 32;
        int x = 6, y = sh - 24 - h - 6;
        roundRect(ctx, x, y, w, h, 8, BG);
        PlayerSkinDrawer.draw(ctx, mc.player.getSkinTextures(), x + 4, y + 4, 24);
        ctx.drawText(tr, name, x + 32, y + 5, WHITE, false);
        String hpText = hp + "hp";
        ctx.drawText(tr, hpText, x + w - tr.getWidth(hpText) - 6, y + 5, Config.accentColor(), false);
        int bx = x + 32, by = y + 20, bw = w - 40;
        roundRect(ctx, bx, by, bw, 5, 2, 0x40FFFFFF);
        roundRect(ctx, bx, by, Math.max(2, (int) (bw * ratio)), 5, 2, Config.accentColor());
    }

    private static void armor(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int sw, int sh) {
        int w = 24, h = 4 * 20 + 8;
        int x = sw - w - 6, y = sh / 2 - h / 2;
        roundRect(ctx, x, y, w, h, 8, BG);
        for (int i = 0; i < 4; i++) {
            int sy = y + 4 + i * 20;
            roundRect(ctx, x + 2, sy, 20, 20, 5, SLOT);
            ItemStack s = mc.player.getEquippedStack(ARMOR[i]);
            if (!s.isEmpty()) {
                ctx.drawItem(s, x + 4, sy + 2);
                ctx.drawStackOverlay(tr, s, x + 4, sy + 2);
            }
        }
    }

    private static void emoteBubble(DrawContext ctx, TextRenderer tr, int sw, int sh) {
        if (System.currentTimeMillis() > Config.emoteUntil || Config.emoteText.isEmpty()) return;
        int w = tr.getWidth(Config.emoteText) + 20;
        int x = (sw - w) / 2, y = sh - 80;
        roundRect(ctx, x, y, w, 18, 9, BG);
        ctx.drawText(tr, Config.emoteText, x + 10, y + 5, Config.accentColor(), false);
    }

    private static void hotbar(DrawContext ctx, TextRenderer tr, MinecraftClient mc, int sw, int sh) {
        int slot = 20, gap = 2, pad = 6;
        int w = 9 * slot + 8 * gap + pad * 2;
        int h = slot + pad * 2;
        int x = (sw - w) / 2;
        int y = sh - h - 2;
        roundRect(ctx, x, y, w, h, 10, BG);
        int selected = mc.player.getInventory().selectedSlot;
        int sel = (Config.accentColor() & 0x00FFFFFF) | 0x80000000;
        for (int i = 0; i < 9; i++) {
            int sx = x + pad + i * (slot + gap);
            int sy = y + pad;
            roundRect(ctx, sx, sy, slot, slot, 5, i == selected ? sel : SLOT);
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (!stack.isEmpty()) {
                ctx.drawItem(stack, sx + 2, sy + 2);
                ctx.drawStackOverlay(tr, stack, sx + 2, sy + 2);
            }
        }
    }

    private static void roundRect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < h; i++) {
            int d = i < r ? r - i : (i >= h - r ? i - (h - r) + 1 : 0);
            int inset = 0;
            if (d > 0) {
                double dd = d - 0.5;
                inset = (int) Math.round(r - Math.sqrt(Math.max(0, (double) r * r - dd * dd)));
            }
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
        }
    }
}
