package com.darkclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class DarkClient implements ClientModInitializer {
    private static KeyBinding menuKey, heartKey, musicKey, happyKey, waveKey;

    @Override
    public void onInitializeClient() {
        String cat = "category.dark_client";
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.dark_client.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, cat));
        heartKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.dark_client.heart", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, cat));
        musicKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.dark_client.music", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, cat));
        happyKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.dark_client.happy", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, cat));
        waveKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.dark_client.wave", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, cat));

        HudRenderCallback.EVENT.register(DarkHud::render);

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (menuKey.wasPressed()) mc.setScreen(new DarkMenu());
            while (heartKey.wasPressed()) Emotes.play(mc, 0);
            while (musicKey.wasPressed()) Emotes.play(mc, 1);
            while (happyKey.wasPressed()) Emotes.play(mc, 2);
            while (waveKey.wasPressed()) Emotes.play(mc, 4);
            Cosmetics.tick(mc);
        });

        // Telefonda tugma yo'q bo'lsa: chatga /dark deb yozing
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("dark").executes(ctx -> {
                MinecraftClient mc = MinecraftClient.getInstance();
                mc.send(() -> mc.setScreen(new DarkMenu()));
                return 1;
            }))
        );
    }
}
