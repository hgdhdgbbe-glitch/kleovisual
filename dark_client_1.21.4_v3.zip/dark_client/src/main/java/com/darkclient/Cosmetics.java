package com.darkclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

public final class Cosmetics {
    private Cosmetics() {}

    public static void tick(MinecraftClient mc) {
        if (Config.aura == 0 || mc.player == null || mc.world == null || mc.isPaused()) return;
        if (mc.player.age % 2 != 0) return;
        ParticleEffect type = switch (Config.aura) {
            case 1 -> ParticleTypes.END_ROD;
            case 2 -> ParticleTypes.HEART;
            case 3 -> ParticleTypes.FLAME;
            default -> ParticleTypes.SOUL_FIRE_FLAME;
        };
        double angle = mc.player.age * 0.35;
        double y = mc.player.getY() + (mc.player.age % 24) / 12.0;
        double x = mc.player.getX() + Math.cos(angle) * 0.8;
        double z = mc.player.getZ() + Math.sin(angle) * 0.8;
        mc.world.addParticle(type, x, y, z, 0, 0.01, 0);
    }
}
