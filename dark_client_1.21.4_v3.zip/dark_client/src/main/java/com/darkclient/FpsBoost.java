package com.darkclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.SimpleOption;

public final class FpsBoost {
    private static boolean saved = false;
    private static int oldView, oldBlend;
    private static boolean oldShadows;
    private static Object oldParticles;
    private static CloudRenderMode oldClouds;
    private static GraphicsMode oldGraphics;

    private FpsBoost() {}

    // Zarrachalar rejimini eng past (MINIMAL) qiymatga qo'yadi
    private static <E extends Enum<E>> void setLast(SimpleOption<E> opt) {
        E[] vals = opt.getValue().getDeclaringClass().getEnumConstants();
        opt.setValue(vals[vals.length - 1]);
    }

    @SuppressWarnings("unchecked")
    private static <T> void restore(SimpleOption<T> opt, Object value) {
        opt.setValue((T) value);
    }

    public static void apply(MinecraftClient mc) {
        GameOptions o = mc.options;
        if (!saved) {
            oldView = o.getViewDistance().getValue();
            oldBlend = o.getBiomeBlendRadius().getValue();
            oldShadows = o.getEntityShadows().getValue();
            oldParticles = o.getParticles().getValue();
            oldClouds = o.getCloudRenderMode().getValue();
            oldGraphics = o.getGraphicsMode().getValue();
            saved = true;
        }
        o.getViewDistance().setValue(Math.min(oldView, 8));
        o.getBiomeBlendRadius().setValue(0);
        o.getEntityShadows().setValue(false);
        setLast(o.getParticles());
        o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        o.getGraphicsMode().setValue(GraphicsMode.FAST);
    }

    public static void revert(MinecraftClient mc) {
        if (!saved) return;
        GameOptions o = mc.options;
        o.getViewDistance().setValue(oldView);
        o.getBiomeBlendRadius().setValue(oldBlend);
        o.getEntityShadows().setValue(oldShadows);
        restore(o.getParticles(), oldParticles);
        o.getCloudRenderMode().setValue(oldClouds);
        o.getGraphicsMode().setValue(oldGraphics);
        saved = false;
    }
}
