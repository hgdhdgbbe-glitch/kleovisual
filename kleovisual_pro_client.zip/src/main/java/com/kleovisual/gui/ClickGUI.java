package com.kleovisual.gui;

import java.util.ArrayList;
import java.util.List;

public class ClickGUI {
    private String searchQuery = "";
    private String selectedCategory = "Visual";
    private List<String> modules = new ArrayList<>();

    public ClickGUI() {
        // Active Modules List
        modules.add("Nikni Himoyalash (NameProtect)");
        modules.add("Renderni Yashirish (HideRender)");
        modules.add("Optimizator (FPS Boost)");
        modules.add("Modullar Ro'yxati (ArrayList)");
        modules.add("Effektlar (Walk Trails)");
        modules.add("Zirh Ogohlantirishi (Armor HUD)");
        modules.add("Dinamik Orol (Dynamic Island)");
        modules.add("Nishon (Custom Crosshair)");
        modules.add("Ekran Nisbati (Aspect Ratio)");
        modules.add("Traektoriya (Pearl/Arrow)");
        modules.add("Motion Blur");
        modules.add("To'lqin Effekti (Wave Visual)");
        modules.add("O'ldirish Effekti (Kill Effect)");
        modules.add("Krit Tovushi (Crit Sound)");
        modules.add("Aurora Ob-Havo (Custom Sky)");
        modules.add("Chiroyli Invertar (Custom UI)");
    }

    public void renderMenu() {
        System.out.println("=========================================");
        System.out.println("       ASP VISUAL MENU - KLEOVISUAL     ");
        System.out.println("=========================================");
        System.out.println("Kategoriyalar: [Klient] [HUD] [Ko'rinish] [Dunyo] [Zarralar]");
        System.out.println("Tanlangan Kategoriya: " + selectedCategory);
        System.out.println("Qidiruv: " + searchQuery);
        System.out.println("-----------------------------------------");
        for (String module : modules) {
            System.out.println("[ON] " + module);
        }
        System.out.println("=========================================");
    }
}
