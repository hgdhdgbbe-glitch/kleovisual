package com.kleovisual.modules.inventory;

public class CustomInventory {
    public static void renderBlurInventory() {
        System.out.println("[Inventory UI] Shaffof va blur effektli chiroyli inventar interfeysi render qilinmoqda.");
    }
}
