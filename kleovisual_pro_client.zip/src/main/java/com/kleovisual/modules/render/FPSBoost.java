package com.kleovisual.modules.render;

public class FPSBoost {
    private static boolean fastRender = true;
    private static boolean optimizeParticles = true;
    private static boolean disableShadows = true;
    private static boolean chunkOptimization = true;

    public static void optimizeGraphics() {
        System.out.println("[FPS Boost Pro] Optimizatsiya ishga tushdi:");
        System.out.println(" - Fast Render: " + fastRender);
        System.out.println(" - Zarrachalar optimizatsiyasi: " + optimizeParticles);
        System.out.println(" - Keraksiz soyalar o'chirildi: " + disableShadows);
        System.out.println(" - Chanklar yuklanishi tezlashtirildi: " + chunkOptimization);
        System.out.println(" -> MAXIMAL FPS BOOST FAOL!");
    }
}
