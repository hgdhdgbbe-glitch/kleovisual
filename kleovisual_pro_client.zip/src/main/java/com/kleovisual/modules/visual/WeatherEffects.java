package com.kleovisual.modules.visual;

public class WeatherEffects {
    public static void renderAuroraSky() {
        System.out.println("[Weather] Aurora Borealis (Shimol Yog'dusi) osmon effekti yonmoqda...");
        System.out.println("[Weather] Binafsharang va yashil kosmik bulutlar render qilinmoqda.");
    }

    public static void renderWalkParticles(double x, double y, double z) {
        System.out.println("[Particle Trails] O'yinchi harakatlanmoqda (" + x + ", " + y + ", " + z + ") - sehrli izlar hosil bo'lmoqda.");
    }
}
