package com.kleovisual.modules.cosmetics;

public class Cosmetics {
    public static void loadWingsAndCapes() {
        System.out.println("[Cosmetics] Qanotlar va Plashlar yuklandi.");
        System.out.println("[Cosmetics] BlockAnimatsiya va aura effektlari tayyor.");
    }
}
