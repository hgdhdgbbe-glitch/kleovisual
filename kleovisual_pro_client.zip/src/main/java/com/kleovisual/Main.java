package com.kleovisual;

import com.kleovisual.gui.ClickGUI;
import com.kleovisual.modules.render.FPSBoost;
import com.kleovisual.modules.visual.WeatherEffects;
import com.kleovisual.modules.cosmetics.Cosmetics;
import com.kleovisual.modules.inventory.CustomInventory;

public class Main {
    public static void main(String[] args) {
        System.out.println("*****************************************");
        System.out.println("   KLEOVISUAL CLIENT PRO - INITIALIZED   ");
        System.out.println("*****************************************");
        
        FPSBoost.optimizeGraphics();
        Cosmetics.loadWingsAndCapes();
        CustomInventory.renderBlurInventory();
        
        WeatherEffects.renderAuroraSky();
        WeatherEffects.renderWalkParticles(100.5, 64.0, -200.3);
        
        ClickGUI gui = new ClickGUI();
        gui.renderMenu();
    }
}
