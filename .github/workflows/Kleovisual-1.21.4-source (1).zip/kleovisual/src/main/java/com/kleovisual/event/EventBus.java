package com.kleovisual.event;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

public final class EventBus {
    private static final Map<Class<?>, List<Consumer<Object>>> HANDLERS = new HashMap<>();

    @SuppressWarnings("unchecked")
    public static <T extends Event> void on(Class<T> type, Consumer<T> handler) {
        HANDLERS.computeIfAbsent(type, k -> new CopyOnWriteArrayList<>()).add((Consumer<Object>) handler);
    }

    public static <T extends Event> T post(T event) {
        List<Consumer<Object>> list = HANDLERS.get(event.getClass());
        if (list != null) for (Consumer<Object> h : list) h.accept(event);
        return event;
    }
    private EventBus() {}
}
