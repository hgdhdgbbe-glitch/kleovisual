package com.kleovisual;

import com.kleovisual.render.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

public class TargetHud {
    private static float smooth = 0f, fade = 0f;
    private static LivingEntity last;

    public static void render(DrawContext ctx, MinecraftClient mc) {
        Entity e = mc.targetedEntity;
        if (e instanceof LivingEntity le) { last = le; fade = Math.min(1f, fade + 0.12f); }
        else fade = Math.max(0f, fade - 0.08f);
        if (last == null || fade <= 0.01f) return;

        LivingEntity le = last;
        int w = 140, h = 42;
        int x = ctx.getScaledWindowWidth() / 2 + 24;
        int y = ctx.getScaledWindowHeight() / 2 + 24;
        int a = (int) (fade * 255);

        float max = Math.max(le.getMaxHealth(), 1f);
        float frac = Math.min(le.getHealth() / max, 1f);
        smooth += (frac - smooth) * 0.15f;

        RenderUtil.shadow(ctx, x, y, w, h, 6, 5);
        RenderUtil.glow(ctx, x, y, w, h, 6, 0x8A5CFF, 4);
        RenderUtil.roundRect(ctx, x, y, w, h, 6, RenderUtil.withAlpha(0x14141E, (int) (fade * 215)));

        ctx.drawText(mc.textRenderer, le.getName(), x + 8, y + 7, RenderUtil.withAlpha(0xFFFFFF, Math.max(a, 5)), true);
        ctx.drawText(mc.textRenderer, String.format("%.1f HP", le.getHealth()), x + 8, y + 19,
                RenderUtil.withAlpha(0xBBBBCC, Math.max(a, 5)), true);

        int bx = x + 8, by = y + 31, bw = w - 16;
        RenderUtil.roundRect(ctx, bx, by, bw, 5, 2, RenderUtil.withAlpha(0x303040, (int) (fade * 255)));
        int col = frac > 0.5f ? 0x55FF55 : frac > 0.25f ? 0xFFAA00 : 0xFF4444;
        int fw = Math.max(4, (int) (bw * smooth));
        RenderUtil.roundRect(ctx, bx, by, fw, 5, 2, RenderUtil.withAlpha(col, (int) (fade * 255)));
    }
}
