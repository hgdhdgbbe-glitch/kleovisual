package com.kleovisual.cosmetic;
import net.minecraft.util.Identifier;
public final class CapeManager {
    public static boolean enabled = true;
    public static final Identifier CAPE = Identifier.of("kleovisual", "textures/cape.png");
    private CapeManager() {}
}
