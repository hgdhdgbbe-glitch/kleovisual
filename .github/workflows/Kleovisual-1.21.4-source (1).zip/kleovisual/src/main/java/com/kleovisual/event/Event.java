package com.kleovisual.event;
public interface Event {}
