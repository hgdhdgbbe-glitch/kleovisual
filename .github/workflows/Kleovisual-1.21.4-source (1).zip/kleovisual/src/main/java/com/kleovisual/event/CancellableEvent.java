package com.kleovisual.event;
public class CancellableEvent implements Event {
    private boolean cancelled;
    public boolean isCancelled() { return cancelled; }
    public void cancel() { cancelled = true; }
}
