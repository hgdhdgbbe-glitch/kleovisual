package com.kleovisual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Pulsing ring around the crosshair. */
public class PulseVisual {
    public static void render(DrawContext ctx, MinecraftClient mc) {
        int cx = ctx.getScaledWindowWidth() / 2;
        int cy = ctx.getScaledWindowHeight() / 2;
        double t = (System.currentTimeMillis() % 1500) / 1500.0;
        int r = 6 + (int) (t * 14);
        int alpha = (int) ((1.0 - t) * 200);
        int color = (alpha << 24) | 0x8A5CFF;
        // square-ring outline
        ctx.fill(cx - r, cy - r, cx + r, cy - r + 1, color);
        ctx.fill(cx - r, cy + r - 1, cx + r, cy + r, color);
        ctx.fill(cx - r, cy - r, cx - r + 1, cy + r, color);
        ctx.fill(cx + r - 1, cy - r, cx + r, cy + r, color);
    }
}
