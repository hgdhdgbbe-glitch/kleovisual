package com.kleovisual;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class KleoVisual implements ClientModInitializer {
    public static boolean pulse = true;
    public static boolean targetHud = true;
    private static KeyBinding togglePulse, toggleHud;

    public static void renderAll(net.minecraft.client.gui.DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        com.kleovisual.event.EventBus.post(new com.kleovisual.event.HudRenderEvent(ctx));
    }

    @Override
    public void onInitializeClient() {
        com.kleovisual.event.EventBus.on(com.kleovisual.event.HudRenderEvent.class, e -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (pulse) PulseVisual.render(e.context, mc);
            if (targetHud) TargetHud.render(e.context, mc);
        });
        togglePulse = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kleovisual.pulse", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_BRACKET, "category.kleovisual"));
        toggleHud = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kleovisual.targethud", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_BRACKET, "category.kleovisual"));
        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            while (togglePulse.wasPressed()) pulse = !pulse;
            while (toggleHud.wasPressed()) targetHud = !targetHud;
        });
    }
}
