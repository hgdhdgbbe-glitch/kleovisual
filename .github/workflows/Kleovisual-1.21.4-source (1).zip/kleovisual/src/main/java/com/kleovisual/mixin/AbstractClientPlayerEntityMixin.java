package com.kleovisual.mixin;

import com.kleovisual.cosmetic.CapeManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayerEntity.class)
public class AbstractClientPlayerEntityMixin {
    @Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true)
    private void kleovisual$cape(CallbackInfoReturnable<SkinTextures> cir) {
        if (!CapeManager.enabled) return;
        if ((Object) this != MinecraftClient.getInstance().player) return;
        SkinTextures o = cir.getReturnValue();
        cir.setReturnValue(new SkinTextures(o.texture(), o.textureUrl(), CapeManager.CAPE,
                o.elytraTexture(), o.model(), o.secure()));
    }
}
