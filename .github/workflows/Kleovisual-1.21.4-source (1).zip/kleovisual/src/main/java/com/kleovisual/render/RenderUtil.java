package com.kleovisual.render;

import net.minecraft.client.gui.DrawContext;

/** Rounded rect / glow / shadow / gradient helpers (software-drawn, no custom GLSL). */
public final class RenderUtil {
    public static void roundRect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < h; i++) {
            int d = Math.min(i, h - 1 - i);
            int inset = 0;
            if (d < r) {
                double dy = r - d - 0.5;
                inset = (int) Math.ceil(r - Math.sqrt(Math.max(0, r * r - dy * dy)));
            }
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
        }
    }

    public static void shadow(DrawContext c, int x, int y, int w, int h, int r, int spread) {
        for (int i = spread; i >= 1; i--) {
            int a = (int) (60.0 * (spread - i + 1) / spread / spread * 2);
            roundRect(c, x - i, y - i + 2, w + i * 2, h + i * 2, r + i, (Math.min(a, 40) << 24));
        }
    }

    public static void glow(DrawContext c, int x, int y, int w, int h, int r, int rgb, int spread) {
        for (int i = spread; i >= 1; i--) {
            int a = 70 * (spread - i + 1) / spread / 3;
            roundRect(c, x - i, y - i, w + i * 2, h + i * 2, r + i, (a << 24) | (rgb & 0xFFFFFF));
        }
    }

    public static void gradientV(DrawContext c, int x, int y, int w, int h, int top, int bottom) {
        c.fillGradient(x, y, x + w, y + h, top, bottom);
    }

    public static int withAlpha(int rgb, int a) { return (a << 24) | (rgb & 0xFFFFFF); }
    private RenderUtil() {}
}
