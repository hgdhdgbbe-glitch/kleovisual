package com.kleovisual.event;
import net.minecraft.client.gui.DrawContext;
public class HudRenderEvent implements Event {
    public final DrawContext context;
    public HudRenderEvent(DrawContext context) { this.context = context; }
}
