# Kleovisual (Fabric, Minecraft 1.21.4)
Jar ichida: assets, com, META-INF, kleovisual.mixins.json, kleovisual-refmap.json (avtomatik), fabric.mod.json
Visuals: Pulse (crosshair ring, key ]) and TargetHUD (name + HP bar, key [).
Build: install JDK 21, then run `gradle build` (or add the Gradle wrapper). Jar: build/libs/kleovisual-1.0.0.jar
Put the jar in .minecraft/mods with Fabric Loader + Fabric API for 1.21.4.
